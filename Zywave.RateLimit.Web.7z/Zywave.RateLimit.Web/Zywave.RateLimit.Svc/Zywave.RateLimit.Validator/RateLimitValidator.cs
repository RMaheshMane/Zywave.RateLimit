﻿using System.Net;
using Zywave.RateLimit.DTO.DTO;

namespace Zywave.RateLimit.Validator
{
    /// <summary>
    /// TODO : All the endpoint request validation will do in the Validator project, so we will avoid duplicate code writing when next time have same kind of validation
    /// </summary>
    public static class RateLimitValidator
    {
        public static bool IsValidInput(IdentifierDto  identifierDto)
        {
            return !string.IsNullOrWhiteSpace(identifierDto.ApiKey) ? false : true;
        }
    }
}
