using System.Net;
using Zywave.RateLimit.DTO.DTO;
using Zywave.RateLimit.Service.FixedWindow;
using Zywave.RateLimit.Service.Model;

namespace Zywave.RateLimit.Service.Test
{
    public class RateLimitService_IsUserRequestAllowedTest
    {

        [Fact]
        public async Task Returns_BadRequest_When_User_Send_IdentifierDto_Null()
        {
            // Arrange
            var apiKey = "Test123";
            var rateLimitService = new RateLimitService(3, 10);

            IdentifierDto identifierDto = null;

            // Act            
            var userResponse = await rateLimitService.IsUserRequestAllowedAsync(identifierDto);

            // Assert
            Assert.NotNull(userResponse);
            Assert.Null(userResponse.Data);
            Assert.Equal(HttpStatusCode.BadRequest, userResponse.StatusCode);
            Assert.Equal($"IdentifierDto is null", userResponse.Message);
        }

        [Fact]
        public async Task Returns_BadRequest_When_User_Send_Empty_ApiKey()
        {
            // Arrange
            var apiKey = string.Empty;
            var rateLimitService = new RateLimitService(3, 10);

            // Act            
            var userResponse = await rateLimitService.IsUserRequestAllowedAsync(new IdentifierDto() { ApiKey = apiKey });

            // Assert
            Assert.NotNull(userResponse);
            Assert.Null(userResponse.Data);
            Assert.Equal(HttpStatusCode.BadRequest, userResponse.StatusCode);
            Assert.Equal($"Invalid apiKey {apiKey}", userResponse.Message);
        }

        [Fact]
        public async Task Returns_HttpStatusCodeOK_When_User_Is_WithinTimespan_lessThanOrEqualMaxRequest()
        {
            // Arrange
            var apiKey = "Test123";
            var rateLimitService = new RateLimitService(3, 10);


            // Act            
            var userResponse = await rateLimitService.IsUserRequestAllowedAsync(new IdentifierDto() { ApiKey = apiKey });

            // Assert
            Assert.NotNull(userResponse);
            Assert.Null(userResponse.Data);
            Assert.Equal(HttpStatusCode.OK, userResponse.StatusCode);
        }

        [Fact]
        public async Task Returns_HttpStatusCodeTooManyRequests_When_User_WithinTimespan_MoreThanMaxRequest()
        {
            // Arrange
            var apiKey = "Test123";
            var rateLimitService = new RateLimitService(2, 10);

            rateLimitService._users[apiKey] = new UserRequestCounter
            {
                WindowStart = DateTime.UtcNow,
                RequestCount = 2,   
                Total = 2,
                Allowed = 2,
                Rejected = 0
            };

            // Act
            var userResponse = await rateLimitService.IsUserRequestAllowedAsync(new IdentifierDto() {ApiKey = apiKey });

            // Assert
            Assert.NotNull(userResponse);
            Assert.Null(userResponse.Data);
            Assert.Equal(HttpStatusCode.TooManyRequests, userResponse.StatusCode);
            Assert.Equal($"Too Many Request for user {apiKey}", userResponse.Message);
        }
    }
}