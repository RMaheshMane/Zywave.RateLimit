﻿using System.Net;
using Zywave.RateLimit.DTO.DTO;
using Zywave.RateLimit.Service.FixedWindow;
using Zywave.RateLimit.Service.Model;

namespace Zywave.RateLimit.Service.Test
{
    public class RateLimitService_TotalUserRequestCountsTest
    {

        [Fact]
        public async Task Returns_BadRequest_When_User_Send__ApiKey_Is_NullOrempty()
        {
            // Arrange
            var rateLimitService = new RateLimitService();
            var apiKey = string.Empty;

            // Act
            var userResponse = await rateLimitService.TotalUserRequestCountsAsync(apiKey);

            
            // Assert
            Assert.NotNull(userResponse);
            Assert.Null(userResponse.Data);
            Assert.Equal(HttpStatusCode.BadRequest, userResponse.StatusCode);
            Assert.Equal($"Invalid apiKey {apiKey}", userResponse.Message);
        }

        [Fact]
        public async Task Returns_UnauthorizedRequest_When_User_Send_Invalid_ApiKey()
        {
            // Arrange
            var rateLimitService = new RateLimitService();
            var apiKey = "Test12345";

            rateLimitService._users["Test123"] = new UserRequestCounter
            {
                WindowStart = DateTime.UtcNow,
                RequestCount = 1,
                Total = 1,
                Allowed = 1,
                Rejected = 0
            };

            // Act
            var userResponse = await rateLimitService.TotalUserRequestCountsAsync(apiKey);


            // Assert
            Assert.NotNull(userResponse);
            Assert.Null(userResponse.Data);
            Assert.Equal(HttpStatusCode.Unauthorized, userResponse.StatusCode);
            Assert.Equal($"User Unauthorized", userResponse.Message);
        }

        [Fact]
        public async Task Returns_HttpStatusCodeOK_And_RequestCounts()
        {
            // Arrange
            var apiKey = "Test123";
            var rateLimitService = new RateLimitService(3, 10);

            rateLimitService._users["Test123"] = new UserRequestCounter
            {
                WindowStart = DateTime.UtcNow,
                RequestCount = 1,
                Total = 1,
                Allowed = 1,
                Rejected = 0
            };

            // Act            
            var userResponse = await rateLimitService.IsUserRequestAllowedAsync(new IdentifierDto() { ApiKey = apiKey });
            var user = rateLimitService._users[apiKey];

            // Assert
            Assert.NotNull(userResponse);
            Assert.Null(userResponse.Data);
            Assert.Equal(HttpStatusCode.OK, userResponse.StatusCode);            
            Assert.Equal(2, user.RequestCount);
            Assert.Equal(2, user.Allowed);
            Assert.Equal(2, user.Total);
            Assert.Equal(0, user.Rejected);

        }

        [Fact]
        public async Task Returns_TotalUserRequestCounts()
        {
            // Arrange (mocked user data)
            var apiKey = "Test123";
            var rateLimitService = new RateLimitService(2, 10);

            rateLimitService._users[apiKey] = new UserRequestCounter
            {
                WindowStart = DateTime.UtcNow,
                RequestCount = 2,
                Total = 2,
                Allowed = 2,
                Rejected = 0
            };

            // Act
            var userResponse = await rateLimitService.IsUserRequestAllowedAsync(new IdentifierDto() { ApiKey = apiKey });

            // Assert
            Assert.NotNull(userResponse);
            var user = rateLimitService._users[apiKey];
            Assert.Equal(3, user.Total);
            Assert.Equal(2, user.Allowed);
            Assert.Equal(1, user.Rejected);
        }
    }
}