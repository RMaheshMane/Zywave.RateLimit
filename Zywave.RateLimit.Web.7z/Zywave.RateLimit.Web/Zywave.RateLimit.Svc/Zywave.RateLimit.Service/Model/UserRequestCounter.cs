﻿namespace Zywave.RateLimit.Service.Model
{
    public class UserRequestCounter
    {
        public DateTime WindowStart { get; set; } = DateTime.UtcNow;
        public int RequestCount { get; set; }
        public long Total { get; set; }
        public long Allowed { get; set; }
        public long Rejected { get; set; }
    }
}
