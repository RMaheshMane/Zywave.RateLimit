﻿using Zywave.RateLimit.DTO.DTO;

namespace Zywave.RateLimit.Service
{
    public interface IRateLimitService
    {
        public Task<UserResponse> IsUserRequestAllowedAsync(IdentifierDto identifierDto);

        public Task<UserResponse> TotalUserRequestCountsAsync(string apiKey);
    }
}