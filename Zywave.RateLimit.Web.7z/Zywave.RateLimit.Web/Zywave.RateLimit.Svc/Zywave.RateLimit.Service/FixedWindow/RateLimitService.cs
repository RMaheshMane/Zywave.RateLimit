﻿using NLog;
using System.Collections.Concurrent;
using System.Net;
using Zywave.RateLimit.DTO.DTO;
using Zywave.RateLimit.Service.Model;

namespace Zywave.RateLimit.Service.FixedWindow
{
    public class RateLimitService : IRateLimitService
    {
        private readonly int _maxRequests;
        private readonly TimeSpan _windowDuration;
        private static readonly Logger _logger = LogManager.GetCurrentClassLogger();

        public readonly ConcurrentDictionary<string, UserRequestCounter> _users = new();

        //TODO : - These values Will be read from the configuration.
        public RateLimitService()
        {  
            _maxRequests = 2;
            _windowDuration = TimeSpan.FromSeconds(5);
        }

        public RateLimitService(int maxRequest , int timespan)
        {
            _maxRequests = maxRequest;
            _windowDuration = TimeSpan.FromSeconds(timespan);
        }

        public async Task<UserResponse> IsUserRequestAllowedAsync(IdentifierDto identifierDto)
        {
            if (identifierDto == null)
            {
                _logger.Info("RateLimitService - IsUserRequestAllowedAsync - identifierDto is null");
                return new UserResponse()
                {
                    StatusCode = HttpStatusCode.BadRequest,
                    Message = $"IdentifierDto is null"
                };
            }

            if (string.IsNullOrEmpty(identifierDto.ApiKey))
            {
                _logger.Info("RateLimitService - IsUserRequestAllowedAsync - ApiKey is null");
                return new UserResponse()
                {
                    StatusCode = HttpStatusCode.BadRequest,
                    Message = $"Invalid apiKey {identifierDto.ApiKey}"
                };
            }

            if (await IsUserAllowedAsync(identifierDto.ApiKey))
            {
                return new UserResponse() { StatusCode = HttpStatusCode.OK };
            }
            else
            {
                return new UserResponse() { StatusCode = HttpStatusCode.TooManyRequests, Message = $"Too Many Request for user {identifierDto.ApiKey}" }; ;
            }
                
        }

        public async Task<UserResponse> TotalUserRequestCountsAsync(string apiKey)
        {
            
            if (string.IsNullOrEmpty(apiKey))
            {
                _logger.Info("RateLimitService - TotalUserRequestCountsAsync - ApiKey is IsNullOrEmpty");
                return new UserResponse()
                {
                    StatusCode = HttpStatusCode.BadRequest,
                    Message = $"Invalid apiKey {apiKey}"
                };
            }

            if (_users.TryGetValue(apiKey, out var user))
            {
                if(user == null)
                {
                    _logger.Info($"RateLimitService - TotalUserRequestCountsAsync - user not found for api Key {apiKey}");
                    return new UserResponse()
                    {
                        StatusCode = HttpStatusCode.Unauthorized,
                        Message = "User Unauthorized"
                    };
                }

                var usercounter = new UserRequestCounter()
                {
                    Allowed = user.Allowed,
                    Rejected = user.Rejected,
                    Total = user.Total,
                    RequestCount = user.RequestCount,
                };

                return new UserResponse()
                {
                    StatusCode = HttpStatusCode.OK,
                    Data = usercounter,
                    Message = "User Request Count"
                };
            }

            return new UserResponse();
        }

        private async Task<bool> IsUserAllowedAsync(string key)
        {          
            
            var user = _users.GetOrAdd(key, _ => new UserRequestCounter());
            lock (user)
            {               
                var now = DateTime.UtcNow;

                if (now - user.WindowStart >= _windowDuration)
                {
                    user.WindowStart = now;
                    user.RequestCount = 0;
                }

                user.Total++;
                if (user.RequestCount >= _maxRequests)
                {
                    user.Rejected++;
                    return false;
                }

                user.RequestCount++;
                user.Allowed++;
                return true;
            }
        }       
  
    }
}