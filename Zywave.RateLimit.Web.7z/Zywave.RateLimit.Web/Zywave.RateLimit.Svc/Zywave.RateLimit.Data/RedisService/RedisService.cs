﻿using StackExchange.Redis;

namespace Zywave.RateLimit.Data
{
    public class RedisService : IRedisService
    {
        private readonly IDatabase _db;

        public RedisService(IConnectionMultiplexer redis)
        {
            _db = redis.GetDatabase();
        }

        public Task<string?> GetAsync(string key)
        {
            throw new NotImplementedException();
        }

        public Task RemoveAsync(string key)
        {
            throw new NotImplementedException();
        }

        public Task SetAsync(string key, string value, TimeSpan? expiry = null)
        {
            throw new NotImplementedException();
        }
    }
}