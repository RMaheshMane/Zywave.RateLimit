﻿using System.Net;

namespace Zywave.RateLimit.DTO.DTO
{
    public class UserResponse
    { 
        public object Data { get; set; }
        public HttpStatusCode  StatusCode { get; set; }
        public string Message { get; set; }
    }
}
