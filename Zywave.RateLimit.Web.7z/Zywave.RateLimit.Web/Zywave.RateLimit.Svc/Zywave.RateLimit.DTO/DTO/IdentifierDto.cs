﻿namespace Zywave.RateLimit.DTO.DTO
{
    public class IdentifierDto
    {
       public string UserId { get; set; }
       public string ApiKey { get; set; }
    }
}
