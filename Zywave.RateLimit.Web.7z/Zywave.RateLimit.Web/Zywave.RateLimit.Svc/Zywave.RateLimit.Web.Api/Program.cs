using Microsoft.AspNetCore.RateLimiting;
using System.Threading.RateLimiting;
using Zywave.RateLimit.Service;
using Zywave.RateLimit.Service.FixedWindow;

var builder = WebApplication.CreateBuilder(args);

var policyName = "FixedWindowApiPolicy";

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddSingleton<IRateLimitService, RateLimitService>();

builder.Services.AddRateLimiter(rateLimiterOptions =>
{
    var env = "local"; // Set hardcode value for run project. Environment.GetEnvironmentVariable("RATELIMIT_ENVIRONMENT");

    // load configuration settings as per the environment
    var config = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory())
                                           .AddJsonFile("appsettings.json", optional: false)
                                           .AddJsonFile($"appsettings.{env}.json", optional: env == "local" || env == "Development" || env == "Production")
                                           .AddEnvironmentVariables()
                                           .Build();


    // Read configuration from appsettings.json
    var windowSpanInSec = config.GetValue<int>("FixedWindowApiPolicy:WindowSpanInSec");
    var queueProcessingOrder = config.GetValue<string>("FixedWindowApiPolicy:QueueProcessingOrder");
    var processingOrder = queueProcessingOrder == "OldestFirst" ? QueueProcessingOrder.OldestFirst : QueueProcessingOrder.NewestFirst;
    var queueLimit = config.GetValue<int>("FixedWindowApiPolicy:QueueLimit");
    var permitLimit = config.GetValue<int>("FixedWindowApiPolicy:PermitLimit");

    rateLimiterOptions.AddFixedWindowLimiter(policyName, options =>
    {
        options.Window = TimeSpan.FromSeconds(windowSpanInSec); // how long the fixed windows is 
        options.PermitLimit = permitLimit; // number of request allow in this fixed window 
        options.QueueLimit = queueLimit; // how many request quue it mean time to be process to nexrt window
        options.QueueProcessingOrder = processingOrder;
    });

    // if the request exceeds the limit then throw 429 status code -  
    rateLimiterOptions.OnRejected = async (context, cancellationToken) =>
    {
        context.HttpContext.Response.StatusCode = StatusCodes.Status429TooManyRequests;
        await context.HttpContext.Response.WriteAsync("Too many requests. Please try again later.", cancellationToken);
    };

});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseRateLimiter();

app.UseAuthorization();

//app.MapControllers();

app.MapControllers().RequireRateLimiting(policyName);

app.Run();
