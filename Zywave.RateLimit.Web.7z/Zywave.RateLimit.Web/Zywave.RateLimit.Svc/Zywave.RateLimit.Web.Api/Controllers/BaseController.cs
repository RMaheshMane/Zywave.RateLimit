﻿using Microsoft.AspNetCore.Mvc;
using Zywave.RateLimit.Web.Api.Attribute;

namespace Zywave.RateLimit.Web.Api.Controllers
{
    /// <summary>
    /// All controllers inheritaed from the BaseController - UserAuthorization applied on the base controller 
    /// UserAuthorization exposes check all the API endpoint request should be allowed or not based on the apiKey.
    /// </summary>
    [UserAuthorization]
    public abstract class BaseController : Controller
    {

    }
}
