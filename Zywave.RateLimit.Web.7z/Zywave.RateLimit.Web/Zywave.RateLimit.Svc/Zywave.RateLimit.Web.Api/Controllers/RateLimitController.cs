﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using System.Net;
using Zywave.RateLimit.DTO.DTO;
using Zywave.RateLimit.Service;
using Zywave.RateLimit.Validator;

namespace Zywave.RateLimit.Web.Api.Controllers
{
    // Apply Rate Limit - FixedWindowApiPolicy
    [EnableRateLimiting("FixedWindowApiPolicy")]
    [Route("api/[controller]")]
    [ApiController]
    public class RateLimitController : BaseController
    {
        private readonly IRateLimitService _rateLimitService;

        public RateLimitController(IRateLimitService rateLimitService)
        {
            _rateLimitService = rateLimitService;
        }

        /// <summary>
        /// UserCheck Endpoint - This endpoint worked as per the FixedWindowApiPolicy Configures in Program.cs
        /// For Testing MaxRequests = 2; In WindowDuration = TimeSpan of 5 Sec
        /// </summary>
        /// <param name="apiKey">identifierDto have Required ApiKey or UserId
        /// </param>
        /// <returns>return UserResponse [StatusCode , data , Message]</returns>

        [HttpPost("userCheck")]
        public async Task<IActionResult> UserCheck([FromBody]IdentifierDto identifierDto)
        {
            if (!RateLimitValidator.IsValidInput(identifierDto))
            {
                return Ok(new UserResponse() { StatusCode = HttpStatusCode.BadRequest, Message = $"Invalid user ApiKey" });
            }

            //TODO: Service call 

            return Ok(new UserResponse() { StatusCode = HttpStatusCode.OK });
        }

        /// <summary>
        /// Post /Check Endpoint
        /// For Testing MaxRequests = 2; In WindowDuration = TimeSpan of 5 Sec
        /// </summary>
        /// <param name="identifierDto">UserDto have Required ApiKey or UserId </param>
        /// <param name="cancellationToken"></param>
        /// <returns>return UserResponse [StatusCode , data , Message]</returns>
        [DisableRateLimiting]
        [HttpPost("check")]
        public async Task<IActionResult> Check([FromBody] IdentifierDto identifierDto)
        {
            return Ok(await _rateLimitService.IsUserRequestAllowedAsync(identifierDto));
        }

        /// <summary>
        /// Total User Request Count : In-Memory Storage: The service stored request counts in memory. 
        /// This endpoint call after the Post / Check 
        /// </summary>
        /// <param name="apiKey">User ApiKey</param>   
        /// <returns>return UserResponse [StatusCode , data , Message]</returns>
        [DisableRateLimiting]
        [HttpGet("totalRequestCount")]
        public async Task<UserResponse> GetTotalRequestCount([FromHeader] string apiKey)
        {
            return await _rateLimitService.TotalUserRequestCountsAsync(apiKey);
        }

    }
}