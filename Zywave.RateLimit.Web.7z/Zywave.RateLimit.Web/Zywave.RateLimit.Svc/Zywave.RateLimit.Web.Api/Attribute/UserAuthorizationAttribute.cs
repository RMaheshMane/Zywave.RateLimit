﻿using Microsoft.AspNetCore.Mvc;
using Zywave.RateLimit.Web.Api.Filters;

namespace Zywave.RateLimit.Web.Api.Attribute
{
    /// <summary>
    /// Attribute which allows user authorization using UserValidationFilter
    /// </summary>
    public class UserAuthorizationAttribute : TypeFilterAttribute
    {
        public UserAuthorizationAttribute() : base(typeof(UserValidationFilter)) { }
    }
}
