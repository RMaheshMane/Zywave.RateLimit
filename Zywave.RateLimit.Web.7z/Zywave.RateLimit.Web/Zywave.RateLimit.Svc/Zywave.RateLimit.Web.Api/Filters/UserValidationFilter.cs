﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Zywave.RateLimit.Web.Api.Filters
{
    public class UserValidationFilter : IAsyncAuthorizationFilter
    {
        public async Task OnAuthorizationAsync(AuthorizationFilterContext context)
        {
            var isSucess = await IsValidUserAsync(context);
            if (!isSucess)
            {
                context.Result = new UnauthorizedResult();
            }
        }

        private async Task<bool> IsValidUserAsync(AuthorizationFilterContext context)
        {            
            var apiKey = context.HttpContext.Request.Headers["apiKey"].ToString() ?? string.Empty;            

            if (string.IsNullOrEmpty(apiKey)) return false; 

            var isUserHaveValidKey = ValidateUserApiKeys().Contains(apiKey) ? true : false;

            return isUserHaveValidKey;
        }
        /// <summary>
        /// Api Key validate bases on stored on the Memoery like redish or identity server or database
        /// </summary>
        /// <returns></returns>
        public List<string> ValidateUserApiKeys()
        {
            // TO DO : 1. Read here cofig & check  Env Mode Local/Test/Prod and load the data from the cache caching 
            // TO DO : 2. if match the Key then allow user request execute endpoint else return UnauthorizedResult

            return new List<string>
            {
                "Test1",
                "Test2",
                "Test3",
            };
        }
    }
}
